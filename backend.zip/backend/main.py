import os

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from math_engine import (
    solve_elevation_height_problem,
    solve_equation_choice,
    solve_multiple_choice,
    solve_symbolic_expression,
)
from ocr_engine import extract_latex_from_image
from reasoning_engine import generate_step_by_step_explanation, solve_general_math_problem

app = FastAPI(title="Smart Math AI Engine", version="1.0.0")

# Explicitly allow local dev origins
origins = [
    "http://localhost:5173",
    "http://localhost:5174",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:5174",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class MathRequest(BaseModel):
    query: str


def solve_any_math_problem(problem: str):
    elevation_result = solve_elevation_height_problem(problem)
    if elevation_result:
        return elevation_result["result"], elevation_result["steps"]

    symbolic_result = solve_symbolic_expression(problem)
    if symbolic_result.get("success"):
        return symbolic_result, generate_step_by_step_explanation(problem, symbolic_result)

    ai_result = solve_general_math_problem(problem)
    if not ai_result.get("success"):
        raise HTTPException(status_code=502, detail=ai_result.get("error"))
    return ai_result["result"], ai_result["steps"]


@app.get("/")
def home():
    frontend_dir = os.getenv("SMART_MATH_FRONTEND_DIR")
    index_path = os.path.join(frontend_dir, "index.html") if frontend_dir else None
    if index_path and os.path.isfile(index_path):
        return FileResponse(index_path)
    return {"status": "online", "message": "Smart Math AI API is running"}

@app.get("/health")
def health():
    return {"status": "online"}

@app.post("/api/v1/solve")
def solve_math(request: MathRequest):
    if not request.query.strip():
        raise HTTPException(status_code=400, detail="Query string cannot be empty.")
    
    result, steps = solve_any_math_problem(request.query)
    return {
        "status": "success", 
        "input": request.query, 
        "result": result,
        "steps": steps
    }

@app.post("/api/v1/scan")
async def scan_and_solve(file: UploadFile = File(...)):
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Uploaded file must be an image.")
    
    image_bytes = await file.read()
    ocr_result = extract_latex_from_image(image_bytes)
    
    if not ocr_result.get("success"):
        raise HTTPException(status_code=422, detail=ocr_result.get("error"))
    
    parsed_expr = ocr_result["parsed_expression"]
    full_problem = ocr_result.get("full_problem", parsed_expr)
    if ocr_result["problem_type"] == "comparison":
        math_result = solve_multiple_choice(
            ocr_result["target_expression"],
            ocr_result["relation"],
            ocr_result["choices"]
        )
        if not math_result.get("success"):
            math_result, steps = solve_any_math_problem(full_problem)
        else:
            comparison = "equal to" if math_result["relation"] == "equal" else "not equal to"
            steps = [
                {
                    "step_number": 1,
                    "title": "Evaluate the Target",
                    "description": (
                        f"The target expression {ocr_result['target_expression']} "
                        f"evaluates to {math_result['target_value']}."
                    )
                },
                {
                    "step_number": 2,
                    "title": "Compare the Choices",
                    "description": "; ".join(math_result["evaluated_choices"]) + "."
                },
                {
                    "step_number": 3,
                    "title": "Select the Answer",
                    "description": (
                        f"Choice {math_result['solution'][0]} is {comparison} "
                        f"the target."
                    )
                }
            ]
    elif ocr_result["problem_type"] == "equation_choice":
        math_result = solve_equation_choice(
            ocr_result["equation"],
            ocr_result["solve_for"],
            ocr_result["choices"]
        )
        if not math_result.get("success"):
            math_result, steps = solve_any_math_problem(full_problem)
        else:
            steps = [
                {
                    "step_number": 1,
                    "title": "Solve for the Variable",
                    "description": (
                        f"Solving {ocr_result['equation']} for {ocr_result['solve_for']} "
                        f"gives {math_result['target_value']}."
                    )
                },
                {
                    "step_number": 2,
                    "title": "Compare the Choices",
                    "description": "; ".join(math_result["evaluated_choices"]) + "."
                },
                {
                    "step_number": 3,
                    "title": "Select the Answer",
                    "description": (
                        f"Choice {math_result['solution'][0]} matches the solution."
                    )
                }
            ]
    else:
        math_result, steps = solve_any_math_problem(parsed_expr)
    
    return {
        "status": "success",
        "ocr_data": ocr_result,
        "symbolic_solution": math_result,
        "steps": steps
    }