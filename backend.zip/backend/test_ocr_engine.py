import io
import json
import unittest
from unittest.mock import MagicMock, patch

from PIL import Image

from ocr_engine import extract_latex_from_image


class ImageProblemExtractionTests(unittest.TestCase):
    def setUp(self):
        image_buffer = io.BytesIO()
        Image.new("RGB", (2, 2), "white").save(image_buffer, format="PNG")
        self.image_bytes = image_buffer.getvalue()

    def extract(self, model_result):
        response = MagicMock()
        response.__enter__.return_value.read.return_value = json.dumps({
            "message": {"content": json.dumps(model_result)}
        }).encode("utf-8")
        with patch("ocr_engine.urlopen", return_value=response):
            return extract_latex_from_image(self.image_bytes)

    def test_comparison_without_choices_routes_as_general_problem(self):
        result = self.extract({
            "type": "comparison",
            "question": "Solve 3x + 2 = 11.",
            "target_expression": "",
            "relation": "",
            "choices": {"A": "", "B": "", "C": "", "D": "", "E": ""},
        })

        self.assertTrue(result["success"])
        self.assertEqual(result["problem_type"], "reasoning")
        self.assertEqual(result["parsed_expression"], "Solve 3x + 2 = 11.")

    def test_equation_without_choices_does_not_require_solve_for(self):
        result = self.extract({
            "type": "equation_choice",
            "question": "Solve x + 5 = 12.",
            "equation": "x + 5 = 12",
            "solve_for": "",
            "choices": {"A": "", "B": "", "C": "", "D": "", "E": ""},
        })

        self.assertTrue(result["success"])
        self.assertEqual(result["problem_type"], "expression")
        self.assertEqual(result["parsed_expression"], "x + 5 = 12")

    def test_equation_choice_without_readable_equation_uses_question(self):
        result = self.extract({
            "type": "equation_choice",
            "question": "A number doubled and increased by 3 is 11. Find the number.",
            "equation": "",
            "solve_for": "",
            "choices": {"A": "", "B": "", "C": "", "D": "", "E": ""},
        })

        self.assertTrue(result["success"])
        self.assertEqual(result["problem_type"], "reasoning")
        self.assertIn("Find the number.", result["parsed_expression"])


if __name__ == "__main__":
    unittest.main()
