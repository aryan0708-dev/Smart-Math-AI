import os

import uvicorn
from fastapi.staticfiles import StaticFiles

from main import app


frontend_dir = os.getenv("SMART_MATH_FRONTEND_DIR")
if not frontend_dir or not os.path.isfile(os.path.join(frontend_dir, "index.html")):
    raise RuntimeError("The desktop frontend files could not be found.")

app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="desktop_frontend")


if __name__ == "__main__":
    port = int(os.getenv("SMART_MATH_API_PORT", "8001"))
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")
