import unittest

from main import solve_any_math_problem


class ElevationHeightProblemTests(unittest.TestCase):
    def test_surveyor_problem_solves_without_answer_choices(self):
        problem = (
            "A surveyor wants to know the height of a skyscraper. He places "
            "his inclinometer on a tripod 1m from the ground. At a distance "
            "of 50m from the skyscraper, he records an angle of elevation "
            "of 82°. What is the height of the skyscraper? Give your answer "
            "to one decimal place."
        )

        result, steps = solve_any_math_problem(problem)

        self.assertEqual(result["solution"], ["356.8 m"])
        self.assertEqual(len(steps), 3)
        self.assertIn("tan(82°)", steps[1]["description"])


if __name__ == "__main__":
    unittest.main()
