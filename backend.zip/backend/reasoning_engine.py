import json
import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
OLLAMA_REASONING_MODEL = os.getenv("OLLAMA_REASONING_MODEL", "deepseek-r1:8b")


def _escape_latex_text(value: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
    }
    escaped = "".join(replacements.get(character, character) for character in value)
    return rf"\text{{{escaped}}}"


def solve_general_math_problem(problem: str) -> dict:
    if not problem.strip():
        return {"success": False, "error": "Enter a math problem to solve."}

    prompt = f"""Solve this math problem from any topic. Give a correct answer and
2-6 concise steps. Keep the solution focused and verify the result. Do not
invent missing information; if the problem is ambiguous, ask for clarification.

Return only JSON with:
"answer": final answer as a string,
"latex": only the final mathematical answer in valid KaTeX, no prose,
"steps": array of objects with string fields "title" and "explanation",
"needs_clarification": boolean.

Problem: {problem}
"""

    request = Request(
        f"{OLLAMA_URL.rstrip('/')}/api/chat",
        data=json.dumps({
            "model": OLLAMA_REASONING_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "format": "json",
            "stream": False,
            "options": {
                "temperature": 0.1,
                "num_ctx": 8192,
                "num_predict": 4096
            }
        }).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urlopen(request, timeout=300) as response:
            ollama_response = json.loads(response.read().decode("utf-8"))
    except HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        return {"success": False, "error": f"Ollama returned HTTP {error.code}: {detail}"}
    except URLError as error:
        return {
            "success": False,
            "error": f"Could not connect to Ollama at {OLLAMA_URL}: {error.reason}"
        }
    except Exception as error:
        return {"success": False, "error": f"Ollama math request failed: {str(error)}"}

    if ollama_response.get("error"):
        return {"success": False, "error": ollama_response["error"]}

    content = ollama_response.get("message", {}).get("content", "").strip()
    if not content:
        return {"success": False, "error": "Ollama returned an empty math solution."}

    try:
        solution = json.loads(content)
        if not isinstance(solution, dict):
            raise ValueError("The response must be a JSON object.")

        answer = solution.get("answer")
        if not isinstance(answer, str) or not answer.strip():
            raise ValueError("The model did not return a final answer.")

        raw_steps = solution.get("steps")
        if not isinstance(raw_steps, list):
            raise ValueError("The model did not return solution steps.")

        steps = []
        for index, step in enumerate(raw_steps, start=1):
            if not isinstance(step, dict):
                raise ValueError("The model returned an invalid solution step.")
            title = step.get("title")
            explanation = step.get("explanation")
            if not isinstance(title, str) or not isinstance(explanation, str):
                raise ValueError("The model returned an incomplete solution step.")
            steps.append({
                "step_number": index,
                "title": title,
                "description": explanation
            })

        if not steps:
            raise ValueError("The model returned no solution steps.")

        latex = solution.get("latex")
        if not isinstance(latex, str) or not latex.strip():
            latex = _escape_latex_text(answer.strip())
        else:
            latex = latex.strip()
            if latex.startswith("$$") and latex.endswith("$$"):
                latex = latex[2:-2].strip()
            elif latex.startswith("$") and latex.endswith("$"):
                latex = latex[1:-1].strip()

        if solution.get("needs_clarification") and not answer.lower().startswith("clarification"):
            answer = f"Clarification needed: {answer.strip()}"

        return {
            "success": True,
            "result": {
                "type": "AI solution",
                "solution": [answer.strip()],
                "latex": latex.strip()
            },
            "steps": steps
        }
    except (json.JSONDecodeError, ValueError) as error:
        return {"success": False, "error": f"Could not read the Ollama solution: {str(error)}"}


def generate_step_by_step_explanation(expression: str, solution_result: dict) -> list:
    """
    Generates clear, pedagogical step-by-step explanations for the solved expression.
    """
    steps = []
    try:
        expr_type = solution_result.get("type")
        solution = solution_result.get("solution")
        
        steps.append({
            "step_number": 1,
            "title": "Identify the Expression",
            "description": f"We start with the given mathematical expression or equation: ${expression}$."
        })

        if expr_type == "equation":
            steps.append({
                "step_number": 2,
                "title": "Set Expression to Zero / Rearrange",
                "description": "Bring all terms to one side to set the equation equal to zero for root extraction."
            })
            steps.append({
                "step_number": 3,
                "title": "Solve Symbolically",
                "description": f"Compute the roots/solutions using algebraic manipulation. The resulting values are: {solution}."
            })
        elif expr_type == "derivative":
            steps.append({
                "step_number": 2,
                "title": "Apply Differentiation Rules",
                "description": f"Apply standard power, product, or chain rules to differentiate with respect to the variable."
            })
            steps.append({
                "step_number": 3,
                "title": "Simplified Derivative",
                "description": f"The resulting simplified derivative is {solution}."
            })
        else:
            steps.append({
                "step_number": 2,
                "title": "Evaluate Expression",
                "description": f"Perform the symbolic reduction or evaluation. Result: {solution}."
            })

    except Exception as e:
        steps.append({
            "step_number": 1,
            "title": "Processing Error",
            "description": f"Could not generate fine-grained steps: {str(e)}"
        })

    return steps