import base64
import json
import io
import os
import re
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from PIL import Image

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "minicpm-v:latest")


def _include_choices(question: str, choices) -> str:
    if not isinstance(choices, dict):
        return question.strip()

    missing_choices = []
    for label, value in choices.items():
        if not isinstance(label, str) or not isinstance(value, str) or not value.strip():
            continue
        if not re.search(rf"(?<![A-Za-z0-9]){re.escape(label)}\s*[.)]", question, re.IGNORECASE):
            missing_choices.append(f"{label}. {value.strip()}")

    if missing_choices:
        return f"{question.strip()}\nAnswer choices:\n" + "\n".join(missing_choices)
    return question.strip()


def extract_latex_from_image(image_bytes: bytes) -> dict:
    try:
        image = Image.open(io.BytesIO(image_bytes))
        image.thumbnail((1600, 1600), Image.Resampling.LANCZOS)
        image_format = "JPEG" if image.format == "JPEG" else "PNG"
        if image_format == "JPEG" and image.mode != "RGB":
            image = image.convert("RGB")
        resized_image = io.BytesIO()
        image.save(resized_image, format=image_format, quality=90)
        encoded_image = base64.b64encode(resized_image.getvalue()).decode("ascii")
        
        prompt = """
Read the complete math problem and any answer choices that are visibly present
in the image. Return one valid JSON object with all these string fields:
type, expression, question, target_expression, relation, equation, solve_for,
problem, and choices. choices must be an object with string keys A, B, C, D,
and E. Use empty strings for fields that do not apply and for unused choices.

Use type "expression" for a standalone expression or equation and put its
normalized form in expression.
Use type "comparison" only when answer choices are visible for a question asking
which expressions are equal or not equal to a target. Fill question,
target_expression, relation ("equal" or "not_equal"), and choices.
Use type "equation_choice" when asked to solve an equation for a variable and
at least two visible answer choices are present. Fill question, equation,
solve_for, and choices. Never invent answer choices. If no choices are visible,
use type "expression" for a standalone equation, or type "problem" for any
other question. Do not require or invent choices to solve a problem.
For any other math problem, including word problems, geometry, probability,
statistics, or proofs, use type "problem" and put the complete problem and
choices in problem. Use type "unreadable" only when the text cannot be read.

Transcribe every choice exactly. Normalize multiplication to *, exponents to
**, and use explicit parentheses. Remove commas used as thousands separators.
Do not solve the question. Use only the letters A through E for choice keys.
"""
        
        request = Request(
            f"{OLLAMA_URL.rstrip('/')}/api/chat",
            data=json.dumps({
                "model": OLLAMA_MODEL,
                "messages": [{
                    "role": "user",
                    "content": prompt,
                    "images": [encoded_image]
                }],
                "format": "json",
                "stream": False,
                "options": {
                    "temperature": 0,
                    "num_predict": 256
                }
            }).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        try:
            with urlopen(request, timeout=180) as response:
                ollama_response = json.loads(response.read().decode("utf-8"))
        except HTTPError as error:
            detail = error.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Ollama returned HTTP {error.code}: {detail}") from error
        except URLError as error:
            raise RuntimeError(
                f"Could not connect to Ollama at {OLLAMA_URL}: {error.reason}"
            ) from error

        if ollama_response.get("error"):
            raise RuntimeError(ollama_response["error"])
        extracted_text = ollama_response.get("message", {}).get("content", "").strip()
        if not extracted_text:
            raise ValueError("Ollama returned an empty response.")
        problem = json.loads(extracted_text)

        if not isinstance(problem, dict):
            raise ValueError("The vision model returned an invalid response format.")

        if problem.get("type") == "expression":
            expression = problem.get("expression")
            if not isinstance(expression, str) or not expression.strip():
                raise ValueError("The expression could not be read from the image.")
            return {
                "success": True,
                "problem_type": "expression",
                "parsed_expression": expression.strip(),
                "raw_ocr": extracted_text
            }

        if problem.get("type") == "comparison":
            question = problem.get("question")
            target = problem.get("target_expression")
            relation_value = problem.get("relation")
            relation = (
                relation_value.lower().replace(" ", "_")
                if isinstance(relation_value, str)
                else relation_value
            )
            raw_choices = problem.get("choices")
            choices = {
                label: value.strip()
                for label, value in (raw_choices.items() if isinstance(raw_choices, dict) else [])
                if isinstance(value, str) and value.strip()
            }
            if len(choices) < 2:
                fallback_problem = problem.get("problem") or question
                if isinstance(fallback_problem, str) and fallback_problem.strip():
                    if isinstance(target, str) and target.strip() and target.strip() not in fallback_problem:
                        fallback_problem = (
                            f"{fallback_problem.strip()}\n"
                            f"Target expression: {target.strip()}"
                        )
                    return {
                        "success": True,
                        "problem_type": "reasoning",
                        "parsed_expression": fallback_problem.strip(),
                        "raw_ocr": extracted_text
                    }
            if (
                not isinstance(question, str)
                or not question.strip()
                or not isinstance(target, str)
                or not target.strip()
                or relation not in ("equal", "not_equal")
                or not isinstance(choices, dict)
                or len(choices) < 2
                or any(
                    not isinstance(label, str)
                    or not isinstance(value, str)
                    or not value.strip()
                    for label, value in choices.items()
                )
            ):
                raise ValueError("The multiple-choice problem could not be read completely.")
            return {
                "success": True,
                "problem_type": "comparison",
                "parsed_expression": question.strip(),
                "full_problem": _include_choices(question, choices),
                "target_expression": target.strip(),
                "relation": relation,
                "choices": choices,
                "raw_ocr": extracted_text
            }

        if problem.get("type") == "equation_choice":
            question = problem.get("question")
            equation = problem.get("equation")
            solve_for = problem.get("solve_for")
            raw_choices = problem.get("choices")
            choices = {
                label: value.strip()
                for label, value in (raw_choices.items() if isinstance(raw_choices, dict) else [])
                if isinstance(value, str) and value.strip()
            }
            if (not isinstance(equation, str) or "=" not in equation):
                expression = problem.get("expression")
                if isinstance(expression, str) and "=" in expression:
                    return {
                        "success": True,
                        "problem_type": "expression",
                        "parsed_expression": expression.strip(),
                        "raw_ocr": extracted_text
                    }
                fallback_problem = problem.get("problem") or question
                if len(choices) < 2 and isinstance(fallback_problem, str) and fallback_problem.strip():
                    return {
                        "success": True,
                        "problem_type": "reasoning",
                        "parsed_expression": fallback_problem.strip(),
                        "raw_ocr": extracted_text
                    }
                raise ValueError("The equation and answer choices could not be read completely.")
            if len(choices) < 2:
                return {
                    "success": True,
                    "problem_type": "expression",
                    "parsed_expression": equation.strip(),
                    "raw_ocr": extracted_text
                }
            if (
                not isinstance(question, str)
                or not question.strip()
                or solve_for not in ("x", "y", "z", "t", "theta")
            ):
                raise ValueError("The equation and answer choices could not be read completely.")
            return {
                "success": True,
                "problem_type": "equation_choice",
                "parsed_expression": question.strip(),
                "full_problem": _include_choices(
                    f"{question.strip()}\nEquation: {equation.strip()}",
                    choices
                ),
                "equation": equation.strip(),
                "solve_for": solve_for,
                "choices": choices,
                "raw_ocr": extracted_text
            }

        if problem.get("type") in ("problem", "unsupported"):
            full_problem = problem.get("problem") or problem.get("question")
            if isinstance(full_problem, str) and full_problem.strip():
                raw_choices = problem.get("choices")
                full_problem = _include_choices(full_problem, raw_choices)
                return {
                    "success": True,
                    "problem_type": "reasoning",
                    "parsed_expression": full_problem.strip(),
                    "raw_ocr": extracted_text
                }
            return {
                "success": False,
                "error": "The image does not contain a readable expression or supported multiple-choice math problem."
            }

        if problem.get("type") == "unreadable":
            return {
                "success": False,
                "error": "The math problem could not be read clearly. Upload a sharper or closer image."
            }
        
        raise ValueError("The vision model returned an unsupported response format.")
    except Exception as e:
        return {"success": False, "error": f"Ollama image extraction failed: {str(e)}"}