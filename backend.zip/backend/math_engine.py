import math
import re

import sympy as sp
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application


def _normalize_math_input(expression: str) -> str:
    expression = (
        expression.replace("×", "*")
        .replace("·", "*")
        .replace("⋅", "*")
        .replace("÷", "/")
        .replace("−", "-")
        .replace("–", "-")
        .replace("π", "pi")
    )
    expression = re.sub(r"(?<!\*)\^(?!\*)", "**", expression)
    expression = re.sub(r"(?<=\d),(?=\d{3}(?:\D|$))", "", expression)
    return expression


def solve_elevation_height_problem(query: str):
    normalized_query = re.sub(r"\s+", " ", query.casefold())
    if not re.search(r"\b(?:height|tall)\b", normalized_query):
        return None
    if not re.search(r"\b(?:skyscraper|building|tower)\b", normalized_query):
        return None

    distance_match = re.search(
        r"\b(\d+(?:\.\d+)?)\s*(?:m|meters?|metres?)\b\s+from\s+"
        r"(?:the\s+)?(?:skyscraper|building|tower)\b",
        normalized_query
    )
    angle_match = re.search(
        r"\bangle\s+of\s+elevation\s+(?:of\s+|is\s+|=\s*)?"
        r"(\d+(?:\.\d+)?)\s*(?:°|degrees?)?",
        normalized_query
    )
    observer_height_match = re.search(
        r"\b(\d+(?:\.\d+)?)\s*(?:m|meters?|metres?)\b\s+"
        r"(?:above|from)\s+(?:the\s+)?ground\b",
        normalized_query
    )
    if not distance_match or not angle_match or not observer_height_match:
        return None

    distance = float(distance_match.group(1))
    angle_degrees = float(angle_match.group(1))
    observer_height = float(observer_height_match.group(1))
    if distance <= 0 or not 0 < angle_degrees < 90 or observer_height < 0:
        return None

    rise = distance * math.tan(math.radians(angle_degrees))
    height = rise + observer_height
    decimal_places = 1 if re.search(
        r"\b(?:one|1)\s+decimal\s+place\b|\bnearest\s+tenth\b",
        normalized_query
    ) else 4
    rounded_height = round(height, decimal_places)
    if decimal_places == 1:
        answer_value = f"{rounded_height:.1f}"
        rise_value = f"{rise:.1f}"
    else:
        answer_value = f"{rounded_height:.4f}".rstrip("0").rstrip(".")
        rise_value = f"{rise:.4f}".rstrip("0").rstrip(".")
    answer = f"{answer_value} m"

    return {
        "result": {
            "type": "Trigonometry",
            "solution": [answer],
            "latex": rf"\boxed{{{answer_value}\,\mathrm{{m}}}}"
        },
        "steps": [
            {
                "step_number": 1,
                "title": "Set up the right triangle",
                "description": (
                    f"The horizontal distance is {distance:g} m and the angle "
                    f"of elevation is {angle_degrees:g}°. The instrument is "
                    f"{observer_height:g} m above the ground."
                )
            },
            {
                "step_number": 2,
                "title": "Find the rise above the instrument",
                "description": (
                    f"Using tangent, the rise is {distance:g} × "
                    f"tan({angle_degrees:g}°) ≈ {rise_value} m."
                )
            },
            {
                "step_number": 3,
                "title": "Add the instrument height",
                "description": (
                    f"The skyscraper height is {rise_value} + "
                    f"{observer_height:g} ≈ {answer}."
                )
            }
        ]
    }


def solve_symbolic_expression(query: str) -> dict:
    try:
        x, y, z, t, theta = sp.symbols('x y z t theta')
        
        def sind(val):
            return sp.sin(val * sp.pi / 180)
        def cosd(val):
            return sp.cos(val * sp.pi / 180)
        def tand(val):
            return sp.tan(val * sp.pi / 180)

        local_dict = {
            "x": x, "y": y, "z": z, "t": t, "theta": theta,
            "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
            "sind": sind, "cosd": cosd, "tand": tand,
            "cot": sp.cot, "sec": sp.sec, "csc": sp.csc,
            "asin": sp.asin, "acos": sp.acos, "atan": sp.atan,
            "pi": sp.pi, "E": sp.E, "oo": sp.oo
        }

        transformations = standard_transformations + (implicit_multiplication_application,)
        cleaned_query = _normalize_math_input(query.strip())

        # 1. Handle Integrals (e.g., integrate x**2, x)
        if cleaned_query.startswith("integrate(") or cleaned_query.startswith("int("):
            # Evaluate using SymPy integrate
            inner = parse_expr(cleaned_query[cleaned_query.index("(")+1:-1], local_dict=local_dict, transformations=transformations)
            result = sp.integrate(inner, x)
            return {"success": True, "type": "integral", "solution": [str(result)], "latex": sp.latex(result)}

        # 2. Handle Derivatives (e.g., diff(x**3, x) or derivative)
        elif cleaned_query.startswith("diff(") or cleaned_query.startswith("derivative("):
            inner = parse_expr(cleaned_query[cleaned_query.index("(")+1:-1], local_dict=local_dict, transformations=transformations)
            result = sp.diff(inner, x)
            return {"success": True, "type": "derivative", "solution": [str(result)], "latex": sp.latex(result)}

        # 3. Handle Equations (=)
        elif "=" in cleaned_query:
            lhs_str, rhs_str = cleaned_query.split("=", 1)
            lhs = parse_expr(lhs_str.strip(), local_dict=local_dict, transformations=transformations)
            rhs = parse_expr(rhs_str.strip(), local_dict=local_dict, transformations=transformations)
            equation = sp.Eq(lhs, rhs)
            
            # Detect free symbols to solve for dynamically
            free_syms = equation.free_symbols
            target_sym = x if x in free_syms else (list(free_syms)[0] if free_syms else x)
            
            solutions = sp.solve(equation, target_sym)
            return {"success": True, "type": "equation", "solution": [str(s) for s in solutions], "latex": sp.latex(solutions)}

        # 4. Handle General Expressions (Factor, Expand, Simplify)
        else:
            expr = parse_expr(cleaned_query, local_dict=local_dict, transformations=transformations)
            simplified = sp.simplify(expr)
            
            if simplified.is_number:
                simplified = sp.N(simplified, 4)

            return {"success": True, "type": "expression", "solution": [str(simplified)], "latex": sp.latex(simplified)}

    except Exception as e:
        return {"success": False, "error": str(e)}


def _exact_value(expression: str):
    symbols = sp.symbols("x y z t theta")
    local_dict = dict(zip(("x", "y", "z", "t", "theta"), symbols))
    local_dict.update({
        "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
        "pi": sp.pi, "E": sp.E
    })
    transformations = standard_transformations + (implicit_multiplication_application,)
    return sp.simplify(parse_expr(
        _normalize_math_input(expression),
        local_dict=local_dict,
        transformations=transformations
    ))


def solve_multiple_choice(target_expression: str, relation: str, choices: dict) -> dict:
    if relation not in ("equal", "not_equal"):
        return {"success": False, "error": "Unsupported comparison in the scanned question."}

    try:
        target_value = _exact_value(target_expression)
        evaluated_choices = []
        matching_choices = []

        for label, expression in choices.items():
            value = _exact_value(expression)
            is_equal = sp.simplify(value - target_value) == 0
            evaluated_choices.append(f"{label} = {value}")
            if is_equal == (relation == "equal"):
                matching_choices.append((label, expression, value))

        if len(matching_choices) != 1:
            return {
                "success": False,
                "error": "The choices do not identify exactly one correct answer."
            }

        label, expression, value = matching_choices[0]
        latex = rf"\text{{{label}.}}\quad {sp.latex(value)}"
        return {
            "success": True,
            "type": "multiple_choice",
            "solution": [f"{label}. {expression}"],
            "latex": latex,
            "target_value": str(target_value),
            "evaluated_choices": evaluated_choices,
            "relation": relation
        }
    except Exception as e:
        return {"success": False, "error": f"Could not compare the scanned choices: {str(e)}"}


def solve_equation_choice(equation: str, solve_for: str, choices: dict) -> dict:
    if solve_for not in ("x", "y", "z", "t", "theta") or "=" not in equation:
        return {"success": False, "error": "The scanned equation or variable is not supported."}

    try:
        lhs_text, rhs_text = equation.split("=", 1)
        lhs = _exact_value(lhs_text)
        rhs = _exact_value(rhs_text)
        variable = sp.Symbol(solve_for)
        solutions = sp.solve(sp.Eq(lhs, rhs), variable)
        if len(solutions) != 1:
            return {"success": False, "error": "Could not find one unique solution for the variable."}

        solution = sp.simplify(solutions[0])
        evaluated_choices = []
        matching_choices = []
        for label, expression in choices.items():
            if "=" in expression:
                choice_lhs, choice_rhs = expression.split("=", 1)
                difference = sp.simplify(_exact_value(choice_lhs) - _exact_value(choice_rhs))
                is_correct = sp.simplify(difference.subs(variable, solution)) == 0
                rendered_choice = expression
            else:
                choice_value = _exact_value(expression)
                is_correct = sp.simplify(choice_value - solution) == 0
                rendered_choice = f"{solve_for} = {choice_value}"

            evaluated_choices.append(f"{label}: {rendered_choice}")
            if is_correct:
                matching_choices.append((label, expression))

        if len(matching_choices) != 1:
            return {
                "success": False,
                "error": "The choices do not identify exactly one correct answer."
            }

        label, expression = matching_choices[0]
        latex = rf"\text{{{label}.}}\quad {sp.latex(sp.Eq(variable, solution))}"
        return {
            "success": True,
            "type": "equation_choice",
            "solution": [f"{label}. {expression}"],
            "latex": latex,
            "target_value": f"{solve_for} = {sp.sstr(solution)}",
            "evaluated_choices": evaluated_choices
        }
    except Exception as e:
        return {"success": False, "error": f"Could not solve the scanned equation: {str(e)}"}