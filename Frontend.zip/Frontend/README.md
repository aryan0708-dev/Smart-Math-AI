# Smart Math AI Desktop App

## Run from this workspace

1. Install frontend packages once with `npm.cmd install` in this folder.
2. Double-click `Start Smart Math AI.bat` in the project root.

The desktop window builds the frontend if needed and starts the backend automatically on port 8001, separate from the web app. It uses the Python virtual environment in the project root, or `python` on `PATH` if that environment is missing. Ollama must be installed with the configured models available.

## Build a Windows installer

Run `npm.cmd run desktop:package` in this folder. The installer is written to `release` and creates Start Menu and desktop shortcuts.

## Development

- `npm.cmd run dev` starts the Vite frontend.
- `npm.cmd run desktop` builds the UI and opens it in the desktop window.
- `npm.cmd run build` checks TypeScript and creates the production frontend.
