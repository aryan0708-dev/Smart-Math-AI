import React, { useEffect, useRef, useState } from 'react';
import axios from 'axios';
import {
  ArrowDown,
  ArrowRight,
  Calculator,
  Check,
  FileImage,
  Image as ImageIcon,
  Lightbulb,
  RefreshCw,
  Sparkles,
  Upload,
  X,
  Zap,
} from 'lucide-react';
import { MathRenderer } from './MathRenderer';
import './App.css';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api/v1';

interface Step {
  step_number: number;
  title: string;
  description: string;
}

function getErrorMessage(error: unknown, fallback: string) {
  if (axios.isAxiosError(error)) {
    const detail = error.response?.data?.detail;
    if (typeof detail === 'string') return detail;
  }
  return fallback;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'text' | 'scan'>('text');
  const [query, setQuery] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!previewUrl) return;
    return () => URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0] || null;
    setFile(selectedFile);
    setPreviewUrl(selectedFile ? URL.createObjectURL(selectedFile) : null);
    setResult(null);
    setError(null);
  };

  const handleTextSolve = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!query.trim() || loading) return;
    setLoading(true);
    setResult(null);
    setError(null);
    try {
      const response = await axios.post(`${API_BASE_URL}/solve`, { query });
      setResult(response.data);
    } catch (requestError) {
      setError(getErrorMessage(requestError, 'Could not solve this math problem.'));
    } finally {
      setLoading(false);
    }
  };

  const handleImageScan = async () => {
    if (!file || loading) return;
    setLoading(true);
    setResult(null);
    setError(null);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post(`${API_BASE_URL}/scan`, formData);
      setResult(response.data);
    } catch (requestError) {
      setError(getErrorMessage(requestError, 'Could not read or solve this image.'));
    } finally {
      setLoading(false);
    }
  };

  const currentResult = result?.result || result?.symbolic_solution;
  const steps: Step[] = result?.steps || [];
  const evaluatedProblem = result?.input || result?.ocr_data?.parsed_expression || '';

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />

      <header className="topbar">
        <a className="brand" href="#" aria-label="Smart Math AI home">
          <span className="brand-mark"><Sparkles size={19} strokeWidth={2.2} /></span>
          <span>Smart Math <span className="brand-light">AI</span></span>
        </a>
        <div className="topbar-status"><span className="status-dot" /> Your AI math tutor</div>
      </header>

      <main className="page-content">
        <section className="hero-section">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> YOUR PERSONAL MATH TUTOR</div>
            <h1>Solve Math Problems <span>with AI</span></h1>
            <p className="hero-description">
              From quick equations to challenging word problems, get clear answers and step-by-step guidance.
            </p>
            <a className="hero-link" href="#solver">
              Start solving <ArrowDown size={16} />
            </a>
            <div className="hero-points">
              <span><Check size={15} /> Step-by-step solutions</span>
              <span><Check size={15} /> Type or scan a problem</span>
            </div>
          </div>

          <div className="hero-art" aria-hidden="true">
            <div className="art-ring art-ring-one" />
            <div className="art-ring art-ring-two" />
            <div className="equation-card equation-card-top">
              <span className="equation-label">ALGEBRA</span>
              <span className="equation-text">x² + y² = r²</span>
            </div>
            <div className="equation-card equation-card-bottom">
              <span className="equation-label">CALCULUS</span>
              <span className="equation-text">∫ f(x) dx</span>
            </div>
            <div className="art-core">
              <div className="art-core-icon"><Sparkles size={30} /></div>
              <span>THINK IT THROUGH</span>
              <strong>Math, made<br />understandable.</strong>
            </div>
            <div className="art-orbit-dot orbit-dot-one" />
            <div className="art-orbit-dot orbit-dot-two" />
          </div>
        </section>

        <section className="workspace-section" id="solver">
          <div className="workspace-heading">
            <div>
              <div className="section-kicker">MATH WORKSPACE</div>
              <h2>What are you working on?</h2>
            </div>
            <div className="workspace-note"><Zap size={15} /> Ready when you are</div>
          </div>

          <div className="workspace-card">
            <div className="mode-switch" role="tablist" aria-label="Problem input method">
              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'text'}
                className={`mode-button ${activeTab === 'text' ? 'active' : ''}`}
                onClick={() => { setActiveTab('text'); setError(null); }}
              >
                <Calculator size={17} /> Type a problem
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'scan'}
                className={`mode-button ${activeTab === 'scan' ? 'active' : ''}`}
                onClick={() => { setActiveTab('scan'); setError(null); }}
              >
                <ImageIcon size={17} /> Upload an image
              </button>
            </div>

            {activeTab === 'text' ? (
              <form className="input-panel fade-in" onSubmit={handleTextSolve}>
                <label className="field-label" htmlFor="math-query">Describe or enter your math problem</label>
                <textarea
                  id="math-query"
                  className="problem-input"
                  rows={4}
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder={'Try “solve 2x + 5 = 17” or type a word problem...'}
                  disabled={loading}
                />
                <div className="input-footer">
                  <span className="input-hint"><Lightbulb size={15} /> Include any details or units from the question.</span>
                  <button className="primary-button" type="submit" disabled={loading || !query.trim()}>
                    {loading ? <><RefreshCw className="spin" size={17} /> Solving...</> : <>Solve problem <ArrowRight size={17} /></>}
                  </button>
                </div>
                <div className="example-row">
                  <span>Need an idea?</span>
                  <button type="button" onClick={() => setQuery('A train travels 180 miles in 3 hours. What is its average speed?')}>Word problem</button>
                  <button type="button" onClick={() => setQuery('integrate(x**2, x)')}>Calculus</button>
                  <button type="button" onClick={() => setQuery('x**2 - 9 = 0')}>Equation</button>
                </div>
              </form>
            ) : (
              <div className="input-panel fade-in">
                <label className="field-label" htmlFor="problem-image">Upload a photo or screenshot of your problem</label>
                <label className={`upload-zone ${file ? 'has-file' : ''}`} htmlFor="problem-image">
                  <input
                    ref={fileInputRef}
                    id="problem-image"
                    className="file-input"
                    type="file"
                    accept="image/png,image/jpeg"
                    onChange={handleFileChange}
                  />
                  <span className="upload-icon">{file ? <FileImage size={25} /> : <Upload size={25} />}</span>
                  <span className="upload-title">{file ? file.name : 'Drop your image here or browse files'}</span>
                  <span className="upload-subtitle">PNG or JPG · Keep the problem clear and readable</span>
                  <span className="browse-button">Choose an image</span>
                </label>

                {previewUrl && (
                  <div className="image-preview">
                    <img src={previewUrl} alt="Preview of the selected math problem" />
                    <button
                      type="button"
                      className="remove-image"
                      aria-label="Remove selected image"
                      onClick={() => {
                        setFile(null);
                        setPreviewUrl(null);
                        if (fileInputRef.current) fileInputRef.current.value = '';
                      }}
                    >
                      <X size={16} />
                    </button>
                  </div>
                )}

                <div className="input-footer scan-footer">
                  <span className="input-hint"><Sparkles size={15} /> We’ll read the problem and show the steps.</span>
                  <button className="primary-button" type="button" disabled={loading || !file} onClick={handleImageScan}>
                    {loading ? <><RefreshCw className="spin" size={17} /> Reading problem...</> : <>Scan &amp; solve <ArrowRight size={17} /></>}
                  </button>
                </div>
              </div>
            )}

            {error && (
              <div className="error-message" role="alert">
                <span className="error-icon">!</span>
                <span>{error}</span>
              </div>
            )}

            {loading && <div className="loading-track"><span /></div>}
          </div>
        </section>

        {result && currentResult && (
          <section className="results-card fade-in" aria-live="polite">
            <div className="results-heading">
              <div className="results-title-icon"><Check size={18} /></div>
              <div>
                <div className="section-kicker">SOLUTION</div>
                <h2>Your answer</h2>
              </div>
              <span className="result-type">{currentResult.type || 'Math problem'}</span>
            </div>

            {evaluatedProblem && (
              <div className="evaluated-problem">
                <span className="field-label">PROBLEM</span>
                <p>{evaluatedProblem}</p>
              </div>
            )}

            <div className="answer-panel">
              <div className="answer-label"><Sparkles size={15} /> FINAL ANSWER</div>
              <MathRenderer latexString={currentResult.latex || currentResult.solution?.[0] || ''} />
            </div>

            {steps.length > 0 && (
              <div className="steps-section">
                <div className="steps-title">
                  <div>
                    <div className="section-kicker">THE METHOD</div>
                    <h3>Step by step</h3>
                  </div>
                  <span>{steps.length} steps</span>
                </div>
                <div className="steps-list">
                  {steps.map((step, index) => (
                    <article className="step-card" key={`${step.step_number}-${step.title}`}>
                      <div className="step-number">{String(index + 1).padStart(2, '0')}</div>
                      <div className="step-content">
                        <h4>{step.title}</h4>
                        <p>{step.description}</p>
                      </div>
                    </article>
                  ))}
                </div>
              </div>
            )}
          </section>
        )}

        <footer className="page-footer">
          <span><Sparkles size={14} /> Smart Math AI</span>
          <span>Make sense of every step.</span>
        </footer>
      </main>
    </div>
  );
}
