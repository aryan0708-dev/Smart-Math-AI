import React, { useEffect, useRef } from 'react';
import katex from 'katex';
import 'katex/dist/katex.min.css';

interface Props {
  latexString: string;
}

export const MathRenderer: React.FC<Props> = ({ latexString }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      try {
        katex.render(latexString, containerRef.current, {
          throwOnError: false,
        });
      } catch {
        containerRef.current.innerText = latexString;
      }
    }
  }, [latexString]);

  return <div ref={containerRef} className="math-renderer" />;
};