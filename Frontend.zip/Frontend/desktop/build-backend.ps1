$ErrorActionPreference = 'Stop'

$projectRoot = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$backendDir = Join-Path $projectRoot 'backend'
$python = Join-Path $projectRoot 'venv\Scripts\python.exe'
$outputDir = Join-Path $PSScriptRoot 'backend-dist'
$workDir = Join-Path $PSScriptRoot 'backend-build'

if (-not (Test-Path $python)) {
    throw "Python virtual environment not found: $python"
}

& $python -m pip install -r (Join-Path $backendDir 'DesktopBuildRequirements.txt')
if ($LASTEXITCODE -ne 0) {
    throw 'Could not install desktop backend build requirements.'
}

& $python -m PyInstaller `
    --noconfirm `
    --clean `
    --onefile `
    --noconsole `
    --name SmartMathAIBackend `
    --distpath $outputDir `
    --workpath $workDir `
    --specpath $workDir `
    --paths $backendDir `
    --collect-all sympy `
    --collect-all PIL `
    --collect-submodules uvicorn `
    (Join-Path $backendDir 'desktop_server.py')
if ($LASTEXITCODE -ne 0) {
    throw 'Could not package the desktop backend.'
}
