const { app, BrowserWindow, dialog } = require('electron');
const { spawn } = require('child_process');
const fs = require('fs');
const http = require('http');
const path = require('path');

const backendUrl = 'http://127.0.0.1:8001';
let backendProcess = null;
let backendOutput = '';

function probeDesktopServer() {
  return new Promise((resolve) => {
    const request = http.get(backendUrl, (response) => {
      const servesFrontend = (response.headers['content-type'] || '').includes(
        'text/html',
      );
      response.resume();
      resolve(response.statusCode === 200 && servesFrontend);
    });
    request.setTimeout(1000, () => request.destroy());
    request.on('error', () => resolve(false));
  });
}

function startBackend(projectRoot, frontendDir) {
  const environment = {
    ...process.env,
    SMART_MATH_FRONTEND_DIR: frontendDir,
    SMART_MATH_API_PORT: '8001',
  };

  if (app.isPackaged) {
    const backendPath = path.join(
      process.resourcesPath,
      'backend',
      'SmartMathAIBackend.exe',
    );
    if (!fs.existsSync(backendPath)) {
      throw new Error(`The bundled backend was not found:\n${backendPath}`);
    }
    backendProcess = spawn(backendPath, [], {
      cwd: app.getPath('userData'),
      env: environment,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
  } else {
    const backendDir = path.join(projectRoot, 'backend');
    const virtualEnvPython = path.join(
      projectRoot,
      'venv',
      'Scripts',
      'python.exe',
    );
    const python = fs.existsSync(virtualEnvPython) ? virtualEnvPython : 'python';
    backendProcess = spawn(
      python,
      [
        '-m',
        'uvicorn',
        'desktop_server:app',
        '--host',
        '127.0.0.1',
        '--port',
        '8000',
      ],
      {
        cwd: backendDir,
        env: environment,
        windowsHide: true,
        stdio: ['ignore', 'pipe', 'pipe'],
      },
    );
  }

  for (const stream of [backendProcess.stdout, backendProcess.stderr]) {
    stream.on('data', (data) => {
      backendOutput = `${backendOutput}${data.toString()}`.slice(-8000);
    });
  }
}

async function waitForBackend() {
  const deadline = Date.now() + 120000;
  while (Date.now() < deadline) {
    if (await probeDesktopServer()) return;
    if (backendProcess && backendProcess.exitCode !== null) {
      throw new Error(
        `The backend exited with code ${backendProcess.exitCode}.\n${backendOutput}`,
      );
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  throw new Error(`The backend did not become ready in time.\n${backendOutput}`);
}

async function createWindow() {
  const projectRoot = path.resolve(__dirname, '..', '..');
  const frontendDir = app.isPackaged
    ? path.join(process.resourcesPath, 'frontend')
    : path.join(projectRoot, 'frontend', 'dist');

  if (!fs.existsSync(path.join(frontendDir, 'index.html'))) {
    throw new Error(
      `The desktop frontend was not built:\n${frontendDir}\n\nRun the desktop launcher again to build it.`,
    );
  }

  if (!(await probeDesktopServer())) {
    startBackend(projectRoot, frontendDir);
    backendProcess.on('error', (error) => {
      backendOutput = `${backendOutput}\n${error.message}`.slice(-8000);
    });
    await waitForBackend();
  }

  const window = new BrowserWindow({
    width: 1280,
    height: 900,
    minWidth: 800,
    minHeight: 600,
    title: 'Smart Math AI',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  await window.loadURL(backendUrl);
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    const [window] = BrowserWindow.getAllWindows();
    if (window) {
      if (window.isMinimized()) window.restore();
      window.focus();
    }
  });

  app.whenReady().then(createWindow).catch((error) => {
    dialog.showErrorBox('Smart Math AI could not start', error.message);
    app.quit();
  });

  app.on('before-quit', () => {
    if (backendProcess && backendProcess.exitCode === null) {
      backendProcess.kill();
      backendProcess = null;
    }
  });

  app.on('window-all-closed', () => app.quit());
}
